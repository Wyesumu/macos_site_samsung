db_file = "db.db" #database file storage
host = "0.0.0.0" #0.0.0.0 to allow outside connection
port = "3131"
secret_key = b'mLIjdm430NLKnjjndoni599Jd' #used to crypt session stored in cookies

UPLOAD_FOLDER = './static/uploads'
THUMBNAIL_FOLDER = './static/thumbnails'

login = 'admin'
password = '24058509qw'
